#!/usr/bin/env node
const WebSocket = require('ws');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { Worker, isMainThread, parentPort, workerData } = require('worker_threads');

const GATEWAY_URL = process.env.GATEWAY_URL || 'wss://webminer.online/ws';
const PAYOUT_ADDRESS = process.env.PAYOUT_ADDRESS || '';
const WORKER_NAME = process.env.WORKER_NAME || 'node-' + Math.random().toString(36).slice(2, 8);
const NUM_THREADS = Math.max(1, parseInt(process.env.THREADS) || (os.cpus().length - 1) || 1);
const CHUNK_ITERATIONS = parseInt(process.env.CHUNK_ITERS) || 12000;
const POWER_PERCENT = Math.max(10, Math.min(100, parseInt(process.env.POWER) || 100));
const WASM_PATH = path.join(__dirname, 'wasm', 'solver_wasm.wasm');
const RECONNECT_MS = 3000;
const STATS_INTERVAL_MS = 3000;

// ── ANSI Colors ─────────────────────────────────────────────────
const C = {
  reset:   '\x1b[0m',
  bold:    '\x1b[1m',
  dim:     '\x1b[2m',
  blue:    '\x1b[38;5;33m',
  cyan:    '\x1b[38;5;44m',
  green:   '\x1b[38;5;40m',
  yellow:  '\x1b[38;5;220m',
  orange:  '\x1b[38;5;208m',
  red:     '\x1b[38;5;196m',
  magenta: '\x1b[38;5;201m',
  white:   '\x1b[38;5;255m',
  gray:    '\x1b[38;5;240m',
  lime:    '\x1b[38;5;118m',
  gold:    '\x1b[38;5;178m',
  sky:     '\x1b[38;5;117m',
  pink:    '\x1b[38;5;213m',
  bgDark:  '\x1b[48;5;16m',
  bgGray:  '\x1b[48;5;235m',
  bgGreen: '\x1b[48;5;22m',
};

// ── WORKER THREAD ───────────────────────────────────────────────
if (!isMainThread) {
  runWorkerThread();
}

async function runWorkerThread() {
  const { wasmPath, chunkIterations, workerIndex } = workerData;
  let powerPercent = workerData.powerPercent;
  const OFF = { header: 0, nonce: 32, target: 96, hash: 160 };

  const wasmBytes = fs.readFileSync(wasmPath);
  const mod = await WebAssembly.instantiate(wasmBytes, {});
  const wasm = mod.instance.exports;

  if (!wasm.memory || !wasm.io_ptr || !wasm.io_len || !wasm.solve) {
    parentPort.postMessage({ type: 'error', message: 'Unexpected engine exports' });
    return;
  }
  if (Number(wasm.io_len()) !== 224) {
    parentPort.postMessage({ type: 'error', message: `Unexpected I/O size ${wasm.io_len()}` });
    return;
  }

  parentPort.postMessage({ type: 'ready' });

  let generation = 0;
  let stopped = false;

  parentPort.on('message', (msg) => {
    if (msg.type === 'job') {
      stopped = false;
      generation++;
      processJob(msg.job, generation);
    } else if (msg.type === 'set_power') {
      powerPercent = Math.max(10, Math.min(100, msg.powerPercent));
    } else if (msg.type === 'stop') {
      stopped = true;
      generation++;
    }
  });

  function hexToFixed(hex, len) {
    hex = String(hex).replace(/^0x/, '');
    if (hex.length > len * 2) throw new Error('hex too wide');
    hex = hex.padStart(len * 2, '0');
    const out = new Uint8Array(len);
    for (let i = 0; i < len; i++) out[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16);
    return out;
  }

  function bytesToHex(bytes) {
    return Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
  }

  async function processJob(job, gen) {
    try {
      const ptr = Number(wasm.io_ptr());
      const mem = new Uint8Array(wasm.memory.buffer, ptr, 224);
      mem.fill(0);
      mem.set(hexToFixed(job.headerHash, 32), OFF.header);
      mem.set(hexToFixed(job.nonceStart, 64), OFF.nonce);
      mem[OFF.nonce] = (workerIndex >>> 24) & 255;
      mem[OFF.nonce + 1] = (workerIndex >>> 16) & 255;
      mem[OFF.nonce + 2] = (workerIndex >>> 8) & 255;
      mem[OFF.nonce + 3] = workerIndex & 255;
      mem.set(hexToFixed(job.shareTarget, 64), OFF.target);

      const started = performance.now();
      let hashCount = 0;

      while (!stopped && gen === generation) {
        const chunkStart = performance.now();
        const found = Number(wasm.solve(chunkIterations));
        const activeMs = Math.max(0.1, performance.now() - chunkStart);
        hashCount += chunkIterations;

        parentPort.postMessage({ type: 'progress', hashes: chunkIterations });

        if (found === 1) {
          const view = new Uint8Array(wasm.memory.buffer, ptr, 224);
          parentPort.postMessage({
            type: 'solution',
            jobId: job.jobId,
            nonce: bytesToHex(view.slice(OFF.nonce, OFF.nonce + 64)),
            hash: bytesToHex(view.slice(OFF.hash, OFF.hash + 64)),
            hashCount,
            elapsedMs: performance.now() - started
          });
          return;
        }

        const delay = powerPercent >= 100 ? 0 : activeMs * ((100 / powerPercent) - 1);
        if (delay > 0) await new Promise(r => setTimeout(r, delay));
      }
    } catch (err) {
      parentPort.postMessage({ type: 'error', message: err.message });
    }
  }
}

// ── MAIN THREAD ─────────────────────────────────────────────────
if (isMainThread) {
  if (!PAYOUT_ADDRESS || !/^qz[0-9A-Za-z]{20,126}$/.test(PAYOUT_ADDRESS)) {
    console.error(`${C.red}ERROR:${C.reset} Set PAYOUT_ADDRESS env var (valid qz… address)`);
    process.exit(1);
  }

  if (!fs.existsSync(WASM_PATH)) {
    console.error(`${C.red}ERROR:${C.reset} Engine module not found at ${WASM_PATH}`);
    process.exit(1);
  }

  // ── Banner ──────────────────────────────────────────────────
  const VER = '8.0.2';
  const BUILD = '20261002';
  const cpuModel = os.cpus()[0]?.model?.trim() || 'Unknown CPU';
  const totalMem = (os.totalmem() / (1024**3)).toFixed(1);

  console.log('');
  console.log(`${C.bgDark}${C.gold}${C.bold}  ╔════════════════════════════════════════════════════════════════╗  ${C.reset}`);
  console.log(`${C.bgDark}${C.gold}${C.bold}  ║                                                                ║  ${C.reset}`);
  console.log(`${C.bgDark}${C.orange}${C.bold}  ║     █████╗ ███╗   ███╗██████╗  ██████╗ ███╗   ██╗               ║  ${C.reset}`);
  console.log(`${C.bgDark}${C.orange}${C.bold}  ║    ██╔══██╗████╗ ████║██╔══██╗██╔═══██╗████╗  ██║               ║  ${C.reset}`);
  console.log(`${C.bgDark}${C.orange}${C.bold}  ║    ███████║██╔████╔██║██████╔╝██║   ██║██╔██╗ ██║               ║  ${C.reset}`);
  console.log(`${C.bgDark}${C.orange}${C.bold}  ║    ██╔══██║██║╚██╔╝██║██╔══██╗██║   ██║██║╚██╗██║               ║  ${C.reset}`);
  console.log(`${C.bgDark}${C.orange}${C.bold}  ║    ██║  ██║██║ ╚═╝ ██║██████╔╝╚██████╔╝██║ ╚████║               ║  ${C.reset}`);
  console.log(`${C.bgDark}${C.orange}${C.bold}  ║    ╚═╝  ╚═╝╚═╝     ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═══╝               ║  ${C.reset}`);
  console.log(`${C.bgDark}${C.lime}${C.bold}  ║          ██████╗ ██╗   ██╗ █████╗ ███╗   ██╗                ║  ${C.reset}`);
  console.log(`${C.bgDark}${C.lime}${C.bold}  ║         ██╔═══██╗██║   ██║██╔══██╗████╗  ██║                ║  ${C.reset}`);
  console.log(`${C.bgDark}${C.lime}${C.bold}  ║         ██║   ██║██║   ██║███████║██╔██╗ ██║                ║  ${C.reset}`);
  console.log(`${C.bgDark}${C.lime}${C.bold}  ║         ██║▄▄ ██║██║   ██║██╔══██║██║╚██╗██║                ║  ${C.reset}`);
  console.log(`${C.bgDark}${C.lime}${C.bold}  ║         ╚██████╔╝╚██████╔╝██║  ██║██║ ╚████║                ║  ${C.reset}`);
  console.log(`${C.bgDark}${C.lime}${C.bold}  ║          ╚══▀▀═╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═══╝                ║  ${C.reset}`);
  console.log(`${C.bgDark}${C.gold}${C.bold}  ║                                                                ║  ${C.reset}`);
  console.log(`${C.bgDark}${C.white}${C.bold}  ║          ${C.sky}v${VER}${C.gray} build ${BUILD}${C.white}   |   ${C.pink}Distributed Compute Engine${C.white}     ║  ${C.reset}`);
  console.log(`${C.bgDark}${C.gold}${C.bold}  ║                                                                ║  ${C.reset}`);
  console.log(`${C.bgDark}${C.gold}${C.bold}  ╚════════════════════════════════════════════════════════════════╝  ${C.reset}`);
  console.log('');
  console.log(`${C.gray}════════════════════════════════════════════════════════════════════════${C.reset}`);
  console.log(`${C.sky}  SYSTEM     ${C.white}${os.type()} ${os.release()} (${os.arch()})${C.reset}`);
  console.log(`${C.sky}  CPU        ${C.white}${cpuModel}${C.reset}`);
  console.log(`${C.sky}  MEMORY     ${C.white}${totalMem} GB${C.reset}`);
  console.log(`${C.sky}  THREADS    ${C.white}${NUM_THREADS} compute thread(s)${C.reset}`);
  console.log(`${C.sky}  POWER      ${C.white}${POWER_PERCENT}%${C.reset}`);
  console.log(`${C.sky}  NODE ID    ${C.white}${WORKER_NAME}${C.reset}`);
  console.log(`${C.sky}  PROJECT    ${C.white}${PAYOUT_ADDRESS.slice(0,16)}…${PAYOUT_ADDRESS.slice(-6)}${C.reset}`);
  console.log(`${C.sky}  ENDPOINT   ${C.white}${GATEWAY_URL}${C.reset}`);
  console.log(`${C.gray}════════════════════════════════════════════════════════════════════════${C.reset}`);
  console.log('');

  let ws = null;
  let workers = [];
  let workersReady = 0;
  let totalSamples = 0;
  let blends = 0;
  let samplesSinceRate = 0;
  let lastRateAt = performance.now();
  let currentGash = 0;
  let peakGash = 0;
  let reconnectTimer = null;
  let statsTimer = null;
  let datasetCount = 0;
  let sessionStartAt = null;

  function formatGash(v) {
    if (v >= 1e9) return (v / 1e9).toFixed(2) + ' G';
    if (v >= 1e6) return (v / 1e6).toFixed(2) + ' M';
    if (v >= 1e3) return (v / 1e3).toFixed(1) + ' K';
    return Math.round(v) + '';
  }

  function elapsed() {
    if (!sessionStartAt) return '00:00:00';
    const s = Math.floor((Date.now() - sessionStartAt) / 1000);
    const h = String(Math.floor(s / 3600)).padStart(2, '0');
    const m = String(Math.floor((s % 3600) / 60)).padStart(2, '0');
    const ss = String(s % 60).padStart(2, '0');
    return `${h}:${m}:${ss}`;
  }

  function ts() {
    return new Date().toTimeString().slice(0, 8);
  }

  function log(icon, color, msg) {
    console.log(`  ${C.gray}${ts()}${C.reset} ${color}${icon}${C.reset} ${msg}`);
  }

  // ── Spawn compute threads ───────────────────────────────────
  function spawnWorkers() {
    workers = [];
    workersReady = 0;
    for (let i = 0; i < NUM_THREADS; i++) {
      const w = new Worker(__filename, {
        workerData: {
          wasmPath: WASM_PATH,
          chunkIterations: CHUNK_ITERATIONS,
          powerPercent: POWER_PERCENT,
          workerIndex: i
        }
      });
      w.on('message', (msg) => onWorkerMessage(msg, w));
      w.on('error', (err) => log('✗', C.red, `Thread error: ${err.message}`));
      workers.push(w);
    }
    log('⚙', C.sky, `Loading ${C.bold}${NUM_THREADS}${C.reset} compute thread(s)...`);
  }

  function onWorkerMessage(msg, worker) {
    if (msg.type === 'ready') {
      workersReady++;
      if (workersReady === NUM_THREADS) {
        log('✓', C.green, `Engine ready ${C.dim}(WASM Accelerated)${C.reset} — ${NUM_THREADS} thread(s) active`);
        connectServer();
      }
    } else if (msg.type === 'progress') {
      totalSamples += msg.hashes;
      samplesSinceRate += msg.hashes;
      const now = performance.now();
      const secs = (now - lastRateAt) / 1000;
      if (secs >= 1) {
        currentGash = samplesSinceRate / secs;
        peakGash = Math.max(peakGash, currentGash);
        samplesSinceRate = 0;
        lastRateAt = now;
      }
    } else if (msg.type === 'solution') {
      log('▶', C.magenta, `Blend complete ${C.dim}→ batch ${msg.jobId.slice(0, 12)}…${C.reset}`);
      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({
          type: 'solution',
          jobId: msg.jobId,
          nonce: msg.nonce,
          hash: msg.hash,
          hashCount: msg.hashCount,
          elapsedMs: msg.elapsedMs
        }));
      } else {
        log('⚠', C.yellow, `Result queued — endpoint offline`);
      }
    } else if (msg.type === 'error') {
      log('✗', C.red, `Thread fault: ${msg.message}`);
    }
  }

  function connectServer() {
    if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) return;
    log('◇', C.sky, `Connecting to compute cluster...`);
    try {
      ws = new WebSocket(GATEWAY_URL, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Origin': 'https://webminer.online'
        }
      });
    } catch (err) {
      log('✗', C.red, `Connection failed: ${err.message}`);
      scheduleReconnect();
      return;
    }

    ws.on('open', () => {
      log('✓', C.green, `Cluster linked`);
      ws.send(JSON.stringify({
        type: 'hello',
        payoutAddress: PAYOUT_ADDRESS,
        worker: WORKER_NAME,
        powerPercent: POWER_PERCENT,
        deviceType: 'browser'
      }));
    });

    ws.on('message', (data) => {
      try { onServerMessage(JSON.parse(data.toString())); }
      catch { log('⚠', C.yellow, 'Malformed response from cluster'); }
    });

    ws.on('error', (err) => log('✗', C.red, `Cluster error: ${err.message}`));

    ws.on('close', (code) => {
      log('⚠', C.yellow, `Cluster disconnected (${code}), reconnecting...`);
      ws = null;
      scheduleReconnect();
    });
  }

  function onServerMessage(msg) {
    if (msg.type === 'ready') {
      log('✓', C.green, `${C.bold}Node online${C.reset} ${C.dim}← ${msg.pool}${C.reset}`);
      sessionStartAt = Date.now();
    } else if (msg.type === 'job') {
      datasetCount++;
      log('◆', C.orange, `Dataset #${datasetCount} ${C.dim}| id:${msg.jobId.slice(0, 12)}… depth:${msg.difficulty}${C.reset}`);
      workers.forEach(m => m.postMessage({ type: 'job', job: msg }));
    } else if (msg.type === 'share_forwarded') {
      blends++;
      log('★', C.lime, `${C.bold}Blender #${blends} OK${C.reset} ${C.dim}→ batch ${msg.jobId.slice(0, 12)}…${C.reset}`);
    } else if (msg.type === 'share_rejected') {
      log('✗', C.red, `Blend rejected: ${msg.reason || 'unknown'}`);
    } else if (msg.type === 'error') {
      log('✗', C.red, `Cluster: ${msg.message}`);
      if (/invalid Quantus address|checksum|payout address|auth/i.test(msg.message || '')) {
        log('✗', C.red, `${C.bold}Fatal error — process terminated${C.reset}`);
        process.exit(1);
      }
    } else if (msg.type === 'power') {
      const p = Math.max(10, Math.min(100, Number(msg.powerPercent)));
      log('⚙', C.sky, `Power adjusted: ${p}%`);
      workers.forEach(m => m.postMessage({ type: 'set_power', powerPercent: p }));
    }
  }

  function scheduleReconnect() {
    if (reconnectTimer) return;
    reconnectTimer = setTimeout(() => {
      reconnectTimer = null;
      connectServer();
    }, RECONNECT_MS);
  }

  // ── Live status bar ─────────────────────────────────────────
  statsTimer = setInterval(() => {
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({
        type: 'stats',
        hashrate: currentGash,
        powerPercent: POWER_PERCENT,
        thermalState: 'normal',
        totalHashes: totalSamples
      }));
    }
    const bar = [
      `${C.bgGray}${C.white}`,
      ` Gash ${C.bold}${C.lime}${formatGash(currentGash)}${C.reset}${C.bgGray}${C.white} sp/s`,
      ` │ Peak ${formatGash(peakGash)}`,
      ` │ Samples ${C.bold}${totalSamples.toLocaleString()}${C.reset}${C.bgGray}${C.white}`,
      ` │ Blender ${C.bold}${C.lime}${blends}${C.reset}${C.bgGray}${C.white}`,
      ` │ Dataset ${datasetCount}`,
      ` │ ${elapsed()}`,
      ` │ Pwr ${POWER_PERCENT}% `,
      C.reset,
    ].join('');
    process.stdout.write(`\r${bar}`);
  }, STATS_INTERVAL_MS);

  // ── Graceful shutdown ───────────────────────────────────────
  process.on('SIGINT', () => {
    console.log('');
    console.log('');
    log('■', C.orange, `${C.bold}Session terminated by user${C.reset}`);
    console.log(`${C.gray}════════════════════════════════════════════════════════════════════════${C.reset}`);
    console.log(`${C.sky}  SESSION    ${C.white}${elapsed()} elapsed${C.reset}`);
    console.log(`${C.sky}  SAMPLES    ${C.white}${totalSamples.toLocaleString()}${C.reset}`);
    console.log(`${C.sky}  BLENDER    ${C.white}${blends} completed${C.reset}`);
    console.log(`${C.sky}  DATASETS   ${C.white}${datasetCount} processed${C.reset}`);
    console.log(`${C.sky}  PEAK GASH  ${C.white}${formatGash(peakGash)} sp/s${C.reset}`);
    console.log(`${C.gray}════════════════════════════════════════════════════════════════════════${C.reset}`);
    console.log(`${C.dim}  AmbonQuan v${VER} — session closed${C.reset}`);
    console.log('');
    workers.forEach(m => { m.postMessage({ type: 'stop' }); m.terminate(); });
    if (ws) ws.close(1000, 'user stop');
    clearInterval(statsTimer);
    process.exit(0);
  });

  // ── Start ───────────────────────────────────────────────────
  spawnWorkers();
}
