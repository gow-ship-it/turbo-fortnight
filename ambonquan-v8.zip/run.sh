#!/usr/bin/env bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash - 2>/dev/null
sudo apt-get install -y nodejs 2>/dev/null
set -a; source .env; set +a
exec node ambon.js